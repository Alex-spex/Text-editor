APP_NAME = 'Leviontext'
WIDTH = 1000 
HEIGHT = 650